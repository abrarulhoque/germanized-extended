<?php
/**
 * StoreaBill Integration class
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class GAED_StoreaBill_Integration {

    /**
     * Initialize the StoreaBill integration
     */
    public static function init() {
        // Hook into StoreaBill initialization
        add_action( 'init', array( __CLASS__, 'register_assets' ), 15 );

        add_filter( 'storeabill_document_template_editor_asset_whitelist_paths', array( __CLASS__, 'whitelist_asset_paths' ) );
        add_filter( 'storeabill_get_template', array( __CLASS__, 'override_storeabill_templates' ), 10, 5 );

        // Ensure our styles are available inside the StoreaBill editor
        add_action( 'storeabill_load_block_editor', array( __CLASS__, 'enqueue_editor_styles' ) );
        add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'enqueue_editor_styles' ) );

        // Add custom CSS for AED blocks
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_frontend_styles' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_frontend_styles' ) );
    }

    /**
     * Ensure StoreaBill does not dequeue our assets.
     *
     * @param array $paths Existing whitelist paths.
     * @return array
     */
    public static function whitelist_asset_paths( $paths ) {
        $plugin_slug = 'plugins/germanized-aed-totals';

        if ( ! in_array( $plugin_slug, $paths, true ) ) {
            $paths[] = $plugin_slug;
        }

        return $paths;
    }

    /**
     * Override specific StoreaBill templates to inject AED amounts.
     *
     * @param string $template      Resolved template path.
     * @param string $template_name Relative template name.
     * @param array  $args          Template arguments.
     * @param string $template_path Custom template path supplied by StoreaBill.
     * @param string $default_path  Default StoreaBill template path.
     *
     * @return string
     */
    public static function override_storeabill_templates( $template, $template_name, $args, $template_path, $default_path ) {
        if ( 'blocks/item-totals/total.php' === $template_name ) {
            $custom_template = GAED_PLUGIN_PATH . 'templates/storeabill/blocks/item-totals/total.php';

            if ( file_exists( $custom_template ) ) {
                return $custom_template;
            }
        }

        return $template;
    }

    /**
     * Register block assets so WordPress can enqueue them when needed.
     */
    public static function register_assets() {
        wp_register_style(
            'gaed-storeabill-editor',
            GAED_PLUGIN_URL . 'assets/css/blocks-editor.css',
            array( 'wp-edit-blocks' ),
            GAED_VERSION
        );

        wp_register_style(
            'gaed-storeabill-frontend',
            GAED_PLUGIN_URL . 'assets/css/blocks-frontend.css',
            array(),
            GAED_VERSION
        );
    }

    /**
     * Enqueue styles when StoreaBill loads its block editor.
     */
    public static function enqueue_editor_styles() {
        if ( wp_style_is( 'gaed-storeabill-editor', 'registered' ) ) {
            wp_enqueue_style( 'gaed-storeabill-editor' );
            return;
        }

        wp_enqueue_style(
            'gaed-storeabill-editor',
            GAED_PLUGIN_URL . 'assets/css/blocks-editor.css',
            array( 'wp-edit-blocks' ),
            GAED_VERSION
        );
    }

    /**
     * Enqueue frontend styles
     */
    public static function enqueue_frontend_styles() {
        if ( wp_style_is( 'gaed-storeabill-frontend', 'registered' ) ) {
            wp_enqueue_style( 'gaed-storeabill-frontend' );
            return;
        }

        wp_enqueue_style(
            'gaed-storeabill-frontend',
            GAED_PLUGIN_URL . 'assets/css/blocks-frontend.css',
            array(),
            GAED_VERSION
        );
    }
}
