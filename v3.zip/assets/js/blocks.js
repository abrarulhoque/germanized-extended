/**
 * AED Total Row Block
 *
 * Clones the StoreaBill item total row block so we inherit its
 * inspector controls, toolbar actions, and markup while rendering
 * totals in AED on the server.
 */
(function ( wp ) {
    'use strict';

    var __ = wp.i18n.__;
    var registerBlockType = wp.blocks.registerBlockType;
    var getBlockType = wp.blocks.getBlockType;
    var domReady = wp.domReady;

    var legacyPlaceholderMigration = {
        attributes: {
            content: {
                type: 'string',
                default: '{total_aed}',
            },
            totalType: {
                type: 'string',
                default: 'total',
            },
            heading: {
                type: 'string',
                default: '',
            },
            hideIfEmpty: {
                type: 'boolean',
                default: false,
            },
            borders: {
                type: 'array',
                default: [],
            },
        },
        isEligible: function ( attributes ) {
            return attributes && typeof attributes.content === 'string' && attributes.content.indexOf( '{total_aed}' ) !== -1;
        },
        migrate: function ( attributes ) {
            var migrated = Object.assign( {}, attributes );

            migrated.content = attributes.content ? attributes.content.replace( '{total_aed}', '{total}' ) : '{total}';

            return migrated;
        },
        save: function () {
            return null;
        },
    };

    domReady( function () {
        var baseBlock = getBlockType( 'storeabill/item-total-row' );

        if ( ! baseBlock ) {
            if ( window.console && typeof window.console.warn === 'function' ) {
                window.console.warn( '[GAED] storeabill/item-total-row block not available. AED block registration skipped.' );
            }
            return;
        }

        var clonedSettings = Object.assign( {}, baseBlock );
        var baseDeprecated = Array.isArray( baseBlock.deprecated ) ? baseBlock.deprecated : [];
        var baseKeywords = Array.isArray( baseBlock.keywords ) ? baseBlock.keywords : [];
        var BaseEdit = baseBlock.edit;

        delete clonedSettings.name;

        clonedSettings.title = __( 'Item Total Row (AED)', 'germanized-aed-totals' );
        clonedSettings.description = __( 'Inserts an item total row rendered in AED.', 'germanized-aed-totals' );
        clonedSettings.icon = baseBlock.icon;
        clonedSettings.category = baseBlock.category || 'storeabill';
        clonedSettings.parent = baseBlock.parent;
        clonedSettings.attributes = baseBlock.attributes;
        clonedSettings.example = baseBlock.example;
        clonedSettings.supports = baseBlock.supports;
        clonedSettings.apiVersion = typeof baseBlock.apiVersion !== 'undefined' ? baseBlock.apiVersion : clonedSettings.apiVersion;
        clonedSettings.usesContext = baseBlock.usesContext;
        clonedSettings.providesContext = baseBlock.providesContext;
        clonedSettings.styles = baseBlock.styles;
        clonedSettings.transforms = baseBlock.transforms;
        clonedSettings.variations = baseBlock.variations;
        clonedSettings.__experimentalLabel = baseBlock.__experimentalLabel;
        clonedSettings.__experimentalSupports = baseBlock.__experimentalSupports;

        clonedSettings.keywords = [
            __( 'AED', 'germanized-aed-totals' ),
        ].concat( baseKeywords.filter( function ( keyword ) {
            return keyword && keyword.toLowerCase() !== 'aed';
        } ) );

        clonedSettings.edit = function ( props ) {
            return BaseEdit( props );
        };

        clonedSettings.save = function () {
            return null;
        };

        clonedSettings.deprecated = [ legacyPlaceholderMigration ].concat( baseDeprecated );

        registerBlockType( 'gaed/aed-total-row', clonedSettings );
    } );
} )( window.wp );
